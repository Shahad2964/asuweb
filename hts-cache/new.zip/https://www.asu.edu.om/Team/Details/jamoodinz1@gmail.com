﻿<!DOCTYPE html>
<!--[if IE 8 ]><html class="no-js oldie ie8" lang="en"> <![endif]-->
<!--[if IE 9 ]><html class="no-js oldie ie9" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html class="no-js" lang="en"> <!--<![endif]-->
<head>

   <!--- basic page needs
   ================================================== -->
   <meta charset="utf-8">
	<title>A’Sharqiyah University</title>
	<meta name="description" content="">  
	<meta name="author" content="">

   <!-- mobile specific metas
   ================================================== -->
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

 	<!-- CSS
   ================================================== -->
   <link rel="stylesheet" href="https://www.asu.edu.om//errorfiles/css/base.css">  
   <link rel="stylesheet" href="https://www.asu.edu.om//errorfiles/css/main.css">

   <!-- script
   ================================================== -->

   <!-- favicons
	================================================== -->

</head>

<body>

	<!-- header 
   ================================================== -->
   <header class="main-header">
   	<div class="row">
   		<div class="logo">
                <a href="https://www.asu.edu.om">
                    <img src="https://www.asu.edu.om/img/logo.png" width="350" />
                </a>
	      </div>   		
   	</div>   

   </header> <!-- /header -->

  
	<!-- main content
   ================================================== -->
   <main id="main-404-content" class="main-content-particle-js">

   	<div class="content-wrap">

		   <div class="shadow-overlay"></div>

		   <div class="main-content">
		   	<div class="row">
		   		<div class="col-twelve">
			  		
                        <h1 class="kern-this">We looked everywhere.</h1>
                        <h3>
                            Looks like this page is not available
                        </h3>

			  			<!--<div class="search">
				      		<input type="text" id="s" name="s" class="search-field" placeholder="Type and hit enter …">
						</div>-->	   			

			   	</div> <!-- /twelve --> 		   			
		   	</div> <!-- /row -->    		 		
		   </div> <!-- /main-content --> 

		   <footer>
		   	<div class="row">

		   		<div class="col-seven tab-full social-links pull-right">
			   		<ul>
				   		<li><a href="https://www.facebook.com/asharqiyahUni"><i class="fa fa-facebook"></i></a></li>
					      <li><a href="https://twitter.com/AsharqiyahUni"><i class="fa fa-twitter"></i></a></li>
					      <li><a href="https://www.instagram.com/asharqiyahuni"><i class="fa fa-instagram"></i></a></li>   	
                         
				   	</ul>
			   	</div>
		   			
		  			<div class="col-five tab-full bottom-links">
			   		<ul class="links">
				   		<li><a href="https://www.asu.edu.om/">Homepage</a></li>
				         <li><a href="https://www.asu.edu.om/post.aspx?aid=14">About</a></li>
				         <li><a href="mailto:a.sharkawy@asu.edu.om">Report Error</a></li>			                    
				   	</ul>

			   	</div>   		   		

		   	</div> <!-- /row -->    		  		
		   </footer>

		</div> <!-- /content-wrap -->
   
   </main> <!-- /main-404-content -->

   <!-- Java Script
   ================================================== --> 
   <script src="https://www.asu.edu.om//errorfiles/js/jquery-2.1.3.min.js"></script>
   <script src="https://www.asu.edu.om//errorfiles/js/plugins.js"></script>
   <script src="https://www.asu.edu.om//errorfiles/js/main.js"></script>

</body>

</html>